import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { useStore, estimateMarketValues, getDealRating, fmtCurrency } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export const Route = createFileRoute('/marketplace-listing')({
  component: MarketplaceListingDetail,
});

function MarketplaceListingDetail() {
  const search = Route.useSearch() as { listingId: string };
  const { marketplace, addOffer, toast } = useStore();
  const listing = marketplace.find((m) => m.id === search.listingId);
  const [offerAmount, setOfferAmount] = useState('');
  const [offerMessage, setOfferMessage] = useState('');
  const [contactMethod, setContactMethod] = useState<'phone' | 'email' | 'chat'>('email');
  const [buyerName, setBuyerName] = useState('');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!listing) {
    return (
      <div className="min-h-screen bg-background p-6 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">Listing Not Found</h1>
          <p className="text-muted-foreground">This listing may have been removed.</p>
        </div>
      </div>
    );
  }

  const marketValues = estimateMarketValues(listing);
  const dealRating = getDealRating(listing.price, marketValues.retail, marketValues.wholesale);

  const handleMakeOffer = async () => {
    if (!offerAmount || !buyerName || !buyerEmail) {
      toast('Please fill in all required fields', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      addOffer({
        listingId: listing.id,
        buyerName,
        buyerEmail,
        buyerPhone,
        offerAmount: parseInt(offerAmount),
        message: offerMessage,
        status: 'pending',
      });
      toast('Offer submitted successfully! Seller will be notified.', 'success');
      setOfferAmount('');
      setOfferMessage('');
      setBuyerName('');
      setBuyerEmail('');
      setBuyerPhone('');
    } catch (error) {
      toast('Failed to submit offer', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const images = listing.imageUrls || [listing.imageUrl];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <Button variant="ghost" className="mb-6" onClick={() => window.history.back()}>
          ← Back to Marketplace
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Images & Details */}
          <div className="lg:col-span-2">
            {/* Main Image */}
            <Card className="overflow-hidden mb-6 bg-card border-border">
              <div className="relative h-96 bg-muted">
                <img
                  src={images[0]}
                  alt={`${listing.year} ${listing.make} ${listing.model}`}
                  className="w-full h-full object-cover"
                />
                {/* Deal Badge */}
                <div className={`absolute top-4 right-4 ${dealRating.bgColor} ${dealRating.color} px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2`}>
                  <span className="text-2xl">{dealRating.emoji}</span>
                  <div>
                    <div>{dealRating.label}</div>
                    <div className="text-xs opacity-90">{dealRating.pctOfMarket}% of market</div>
                  </div>
                </div>
              </div>

              {/* Image Gallery */}
              {images.length > 1 && (
                <div className="p-4 bg-card border-t border-border flex gap-2 overflow-x-auto">
                  {images.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`View ${idx + 1}`}
                      className="h-20 w-20 object-cover rounded cursor-pointer hover:opacity-75 transition-opacity"
                    />
                  ))}
                </div>
              )}
            </Card>

            {/* Title & Price */}
            <div className="mb-6">
              <h1 className="text-4xl font-bold text-foreground mb-2">
                {listing.year} {listing.make} {listing.model}
              </h1>
              <p className="text-xl text-muted-foreground mb-4">{listing.trim}</p>
              <div className="flex items-baseline gap-4">
                <p className="text-5xl font-bold text-primary">{fmtCurrency(listing.price)}</p>
                <div className="text-sm text-muted-foreground">
                  <p>Est. Retail: {fmtCurrency(marketValues.retail)}</p>
                  <p>Est. Wholesale: {fmtCurrency(marketValues.wholesale)}</p>
                </div>
              </div>
            </div>

            {/* Key Specs */}
            <Card className="p-6 mb-6 bg-card border-border">
              <h2 className="text-xl font-bold text-foreground mb-4">Vehicle Specifications</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Mileage</p>
                  <p className="text-lg font-bold text-foreground">{listing.miles.toLocaleString()} mi</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Year</p>
                  <p className="text-lg font-bold text-foreground">{listing.year}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Body Style</p>
                  <p className="text-lg font-bold text-foreground">{listing.bodyStyle}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Engine</p>
                  <p className="text-lg font-bold text-foreground">{listing.engine}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Transmission</p>
                  <p className="text-lg font-bold text-foreground">{listing.transmission}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Drivetrain</p>
                  <p className="text-lg font-bold text-foreground">{listing.drivetrain}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Fuel Type</p>
                  <p className="text-lg font-bold text-foreground">{listing.fuelType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Title Type</p>
                  <p className="text-lg font-bold text-foreground">{listing.titleType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Exterior Color</p>
                  <p className="text-lg font-bold text-foreground">{listing.exteriorColor}</p>
                </div>
              </div>
            </Card>

            {/* Features */}
            {listing.features && listing.features.length > 0 && (
              <Card className="p-6 mb-6 bg-card border-border">
                <h2 className="text-xl font-bold text-foreground mb-4">Features</h2>
                <div className="flex flex-wrap gap-2">
                  {listing.features.map((feature, idx) => (
                    <Badge key={idx} variant="secondary">
                      ✓ {feature}
                    </Badge>
                  ))}
                </div>
              </Card>
            )}

            {/* Description */}
            <Card className="p-6 bg-card border-border">
              <h2 className="text-xl font-bold text-foreground mb-4">Description</h2>
              <p className="text-foreground leading-relaxed">{listing.description}</p>
            </Card>
          </div>

          {/* Right: Seller Info & Make Offer */}
          <div className="lg:col-span-1">
            {/* Seller Card */}
            <Card className="p-6 mb-6 bg-card border-border sticky top-6">
              <h2 className="text-xl font-bold text-foreground mb-4">Seller Information</h2>
              <div className="space-y-3 mb-6">
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Name</p>
                  <p className="text-foreground">{listing.sellerName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-semibold">Location</p>
                  <p className="text-foreground">{listing.location}</p>
                </div>
                {listing.sellerPhone && (
                  <div>
                    <p className="text-sm text-muted-foreground font-semibold">Phone</p>
                    <a href={`tel:${listing.sellerPhone}`} className="text-primary hover:underline">
                      {listing.sellerPhone}
                    </a>
                  </div>
                )}
                {listing.sellerEmail && (
                  <div>
                    <p className="text-sm text-muted-foreground font-semibold">Email</p>
                    <a href={`mailto:${listing.sellerEmail}`} className="text-primary hover:underline">
                      {listing.sellerEmail}
                    </a>
                  </div>
                )}
              </div>

              {/* Contact Methods */}
              <div className="mb-6 pb-6 border-b border-border">
                <p className="text-sm text-muted-foreground font-semibold mb-3">Preferred Contact</p>
                <div className="space-y-2">
                  {listing.contactPreference === 'any' || listing.contactPreference === 'phone' ? (
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      📞 Call Seller
                    </Button>
                  ) : null}
                  {listing.contactPreference === 'any' || listing.contactPreference === 'email' ? (
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      ✉️ Email Seller
                    </Button>
                  ) : null}
                  {listing.contactPreference === 'any' || listing.contactPreference === 'chat' ? (
                    <Button variant="outline" className="w-full justify-start" size="sm">
                      💬 Chat on Platform
                    </Button>
                  ) : null}
                </div>
              </div>

              {/* External Source Link */}
              {listing.sourceUrl && (
                <a
                  href={listing.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block mb-6"
                >
                  <Button variant="outline" className="w-full justify-start">
                    🔗 View Original Listing
                  </Button>
                </a>
              )}
            </Card>

            {/* Make Offer Dialog */}
            <Dialog>
              <DialogTrigger asChild>
                <Button className="w-full mb-4 bg-primary text-primary-foreground hover:bg-primary/90 h-12 text-base font-semibold">
                  💰 Make an Offer
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle className="text-foreground">Make an Offer</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Buyer Info */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Your Name *</label>
                    <Input
                      value={buyerName}
                      onChange={(e) => setBuyerName(e.target.value)}
                      placeholder="John Doe"
                      className="bg-background border-border text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Email *</label>
                    <Input
                      type="email"
                      value={buyerEmail}
                      onChange={(e) => setBuyerEmail(e.target.value)}
                      placeholder="john@example.com"
                      className="bg-background border-border text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Phone</label>
                    <Input
                      type="tel"
                      value={buyerPhone}
                      onChange={(e) => setBuyerPhone(e.target.value)}
                      placeholder="(555) 123-4567"
                      className="bg-background border-border text-foreground"
                    />
                  </div>

                  {/* Offer Amount */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Offer Amount *</label>
                    <div className="flex items-center gap-2">
                      <span className="text-foreground font-bold">$</span>
                      <Input
                        type="number"
                        value={offerAmount}
                        onChange={(e) => setOfferAmount(e.target.value)}
                        placeholder={listing.price.toString()}
                        className="bg-background border-border text-foreground flex-1"
                      />
                    </div>
                    {offerAmount && (
                      <p className="text-xs text-muted-foreground mt-2">
                        {parseInt(offerAmount) < listing.price
                          ? `${Math.round(((listing.price - parseInt(offerAmount)) / listing.price) * 100)}% below asking`
                          : parseInt(offerAmount) > listing.price
                          ? `${Math.round(((parseInt(offerAmount) - listing.price) / listing.price) * 100)}% above asking`
                          : 'At asking price'}
                      </p>
                    )}
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Message</label>
                    <Textarea
                      value={offerMessage}
                      onChange={(e) => setOfferMessage(e.target.value)}
                      placeholder="Add any notes or questions for the seller..."
                      className="bg-background border-border text-foreground min-h-24"
                    />
                  </div>

                  {/* Contact Method */}
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">Preferred Contact Method</label>
                    <select
                      value={contactMethod}
                      onChange={(e) => setContactMethod(e.target.value as 'phone' | 'email' | 'chat')}
                      className="w-full px-3 py-2 bg-background border border-border rounded-md text-foreground text-sm"
                    >
                      <option value="email">Email</option>
                      <option value="phone">Phone</option>
                      <option value="chat">Chat on Platform</option>
                    </select>
                  </div>

                  {/* Submit */}
                  <Button
                    onClick={handleMakeOffer}
                    disabled={isSubmitting}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {isSubmitting ? 'Submitting...' : 'Submit Offer'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </div>
  );
}
