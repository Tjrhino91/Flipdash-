// ─── MarketCheck API Integration ─────────────────────────────────────
// Fetches real vehicle listings from MarketCheck API
// Maps API data into Flipdash MarketplaceListing format
// Flipdash Value Engine runs AFTER data is received

import type { MarketplaceListing } from "./store";

// ─── API Key Management ──────────────────────────────────────────────

let _marketCheckApiKey: string | null = null;

export function setMarketCheckApiKey(key: string): void {
  _marketCheckApiKey = key;
  try {
    localStorage.setItem("marketcheck_api_key", key);
  } catch {
    // localStorage not available
  }
}

export function getMarketCheckApiKey(): string | null {
  if (_marketCheckApiKey) return _marketCheckApiKey;
  try {
    const stored = localStorage.getItem("marketcheck_api_key");
    if (stored) {
      _marketCheckApiKey = stored;
      return stored;
    }
  } catch {
    // localStorage not available
  }
  return null;
}

export function clearMarketCheckApiKey(): void {
  _marketCheckApiKey = null;
  try {
    localStorage.removeItem("marketcheck_api_key");
  } catch {
    // localStorage not available
  }
}

export function hasMarketCheckApiKey(): boolean {
  return !!getMarketCheckApiKey();
}

// ─── Types ───────────────────────────────────────────────────────────

export interface MarketCheckSearchParams {
  year?: string;
  make?: string;
  model?: string;
  zip?: string;
  radius?: number;
  priceMin?: number;
  priceMax?: number;
  milesMin?: number;
  milesMax?: number;
  rows?: number;
  start?: number;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
  sellerType?: "dealer" | "private";
  bodyType?: string;
}

export interface MarketCheckListing {
  id: string;
  vin?: string;
  heading?: string;
  price?: number;
  miles?: number;
  year?: number;
  make?: string;
  model?: string;
  trim?: string;
  body_type?: string;
  exterior_color?: string;
  interior_color?: string;
  dom?: number; // days on market
  first_seen_at?: string;
  last_seen_at?: string;
  seller_type?: string;
  inventory_type?: string;
  source?: string;
  vdp_url?: string;
  media?: {
    photo_links?: string[];
  };
  build?: {
    engine?: string;
    transmission?: string;
    drivetrain?: string;
    fuel_type?: string;
    doors?: number;
    made_in?: string;
    city_miles?: number;
    highway_miles?: number;
  };
  dealer?: {
    id?: number;
    name?: string;
    phone?: string;
    website?: string;
    city?: string;
    state?: string;
    zip?: string;
    latitude?: number;
    longitude?: number;
  };
  extra?: {
    features?: string[];
  };
  dist?: number; // distance from zip
}

export interface MarketCheckResponse {
  num_found: number;
  listings: MarketCheckListing[];
}

// ─── Placeholder image for missing photos ────────────────────────────

const PLACEHOLDER_IMG = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='640' height='400' fill='%23111827'%3E%3Crect width='640' height='400' fill='%23111827'/%3E%3Ctext x='50%25' y='45%25' text-anchor='middle' fill='%234B5563' font-family='system-ui' font-size='24'%3ENo Photo%3C/text%3E%3Ctext x='50%25' y='55%25' text-anchor='middle' fill='%234B5563' font-family='system-ui' font-size='14'%3EAvailable%3C/text%3E%3C/svg%3E";

// ─── Map MarketCheck listing → Flipdash MarketplaceListing ───────────

function mapToFlipdash(mc: MarketCheckListing): MarketplaceListing {
  const photos = mc.media?.photo_links || [];
  const primaryImage = photos.length > 0 ? photos[0] : PLACEHOLDER_IMG;
  const allImages = photos.length > 0 ? photos.slice(0, 10) : [PLACEHOLDER_IMG];

  const city = mc.dealer?.city || "";
  const state = mc.dealer?.state || "";
  const location = city && state ? `${city}, ${state}` : city || state || "Unknown";

  const sellerName = mc.dealer?.name || (mc.seller_type === "private" ? "Private Seller" : "Dealer");

  // Calculate days listed from first_seen_at or dom field
  let daysListed = mc.dom || 0;
  if (!daysListed && mc.first_seen_at) {
    const firstSeen = new Date(mc.first_seen_at);
    const now = new Date();
    daysListed = Math.max(0, Math.floor((now.getTime() - firstSeen.getTime()) / (1000 * 60 * 60 * 24)));
  }

  const postedAt = mc.first_seen_at || new Date().toISOString();

  // Build features list
  const features: string[] = [];
  if (mc.extra?.features) {
    features.push(...mc.extra.features.slice(0, 15));
  }
  if (mc.build?.drivetrain && mc.build.drivetrain !== "FWD") {
    features.push(mc.build.drivetrain);
  }

  return {
    id: `mc-${mc.id}`,
    year: String(mc.year || ""),
    make: mc.make || "",
    model: mc.model || "",
    trim: mc.trim || "",
    miles: mc.miles || 0,
    price: mc.price || 0,
    location,
    exteriorColor: mc.exterior_color || "Unknown",
    imageUrl: primaryImage,
    imageUrls: allImages,
    daysListed,
    source: "marketplace",
    sourceUrl: mc.vdp_url || undefined,
    sellerName,
    sellerPhone: mc.dealer?.phone || undefined,
    sellerEmail: undefined,
    description: mc.heading || `${mc.year} ${mc.make} ${mc.model} ${mc.trim || ""}`.trim(),
    vin: mc.vin || undefined,
    postedAt,
    drivetrain: mc.build?.drivetrain || "FWD",
    fuelType: mc.build?.fuel_type || "Gasoline",
    engine: mc.build?.engine || "",
    bodyStyle: mc.body_type || "Sedan",
    transmission: mc.build?.transmission || "Automatic",
    titleType: "Clean",
    features: features.length > 0 ? features : ["Backup Camera", "Bluetooth"],
    contactPreference: "any",
    interiorColor: mc.interior_color || "Black",
  };
}

// ─── Fetch Listings from MarketCheck ─────────────────────────────────

export async function fetchMarketCheckListings(
  params: MarketCheckSearchParams
): Promise<{ listings: MarketplaceListing[]; totalFound: number; error?: string }> {
  const apiKey = getMarketCheckApiKey();

  if (!apiKey) {
    return {
      listings: [],
      totalFound: 0,
      error: "No MarketCheck API key configured. Add your key in Settings to see live listings.",
    };
  }

  try {
    const queryParams = new URLSearchParams();
    queryParams.set("api_key", apiKey);

    if (params.year) queryParams.set("year", params.year);
    if (params.make) queryParams.set("make", params.make);
    if (params.model) queryParams.set("model", params.model);
    if (params.zip) queryParams.set("zip", params.zip);
    if (params.radius) queryParams.set("radius", String(params.radius));
    if (params.priceMin) queryParams.set("price_range", `${params.priceMin}-${params.priceMax || ""}`);
    else if (params.priceMax) queryParams.set("price_range", `-${params.priceMax}`);
    if (params.milesMax) queryParams.set("miles_range", `-${params.milesMax}`);
    if (params.rows) queryParams.set("rows", String(params.rows));
    if (params.start) queryParams.set("start", String(params.start));
    if (params.sellerType) queryParams.set("seller_type", params.sellerType);
    if (params.bodyType) queryParams.set("body_type", params.bodyType);

    // Sort by newest first by default
    queryParams.set("sort_by", params.sortBy || "first_seen_at");
    queryParams.set("sort_order", params.sortOrder || "desc");

    // Include photo data
    queryParams.set("include_relevant_links", "true");

    const res = await fetch(
      `https://mc-api.marketcheck.com/v2/search/car/active?${queryParams.toString()}`
    );

    if (!res.ok) {
      const errorBody = await res.text().catch(() => "");
      if (res.status === 401 || res.status === 403) {
        return { listings: [], totalFound: 0, error: "Invalid MarketCheck API key. Check your key in Settings." };
      }
      if (res.status === 429) {
        return { listings: [], totalFound: 0, error: "API rate limit reached. Please try again in a moment." };
      }
      throw new Error(`MarketCheck API returned ${res.status}: ${errorBody}`);
    }

    const data: MarketCheckResponse = await res.json();

    const listings = (data.listings || [])
      .filter((l) => l.price && l.price > 0)
      .map(mapToFlipdash);

    return {
      listings,
      totalFound: data.num_found || listings.length,
    };
  } catch (err) {
    return {
      listings: [],
      totalFound: 0,
      error: err instanceof Error ? err.message : "Failed to fetch listings from MarketCheck",
    };
  }
}

// ─── Fetch Single Listing Detail ─────────────────────────────────────

export async function fetchMarketCheckListing(
  listingId: string
): Promise<{ listing: MarketplaceListing | null; error?: string }> {
  const apiKey = getMarketCheckApiKey();
  if (!apiKey) {
    return { listing: null, error: "No MarketCheck API key configured." };
  }

  // Strip the mc- prefix
  const rawId = listingId.replace(/^mc-/, "");

  try {
    const res = await fetch(
      `https://mc-api.marketcheck.com/v2/listing/${rawId}?api_key=${apiKey}`
    );

    if (!res.ok) {
      throw new Error(`MarketCheck API returned ${res.status}`);
    }

    const data: MarketCheckListing = await res.json();
    return { listing: mapToFlipdash(data) };
  } catch (err) {
    return {
      listing: null,
      error: err instanceof Error ? err.message : "Failed to fetch listing detail",
    };
  }
}
